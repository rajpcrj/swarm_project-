from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    SetEnvironmentVariable,
    RegisterEventHandler,
)
from launch.event_handlers import OnProcessExit
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # ── launch‑time arguments ──────────────────────────────
    start_x_arg   = DeclareLaunchArgument("start_x",   default_value="2.0")
    start_y_arg   = DeclareLaunchArgument("start_y",   default_value="2.0")
    length_arg    = DeclareLaunchArgument("length",    default_value="5.0")
    breadth_arg   = DeclareLaunchArgument("breadth",   default_value="3.0")
    win_w_arg     = DeclareLaunchArgument("window_width",  default_value="500")
    win_h_arg     = DeclareLaunchArgument("window_height", default_value="500")

    # ── environment for turtlesim window size ─────────────
    set_win_w = SetEnvironmentVariable(
        "TURTLESIM_WINDOW_WIDTH", LaunchConfiguration("window_width")
    )
    set_win_h = SetEnvironmentVariable(
        "TURTLESIM_WINDOW_HEIGHT", LaunchConfiguration("window_height")
    )

    # ── nodes ─────────────────────────────────────────────
    turtlesim_node = Node(
        package="turtlesim",
        executable="turtlesim_node",
        name="turtlesim_node",
    )

    # 1) field boundary (green outline)
    drawing_node = Node(
        package="agribot",        # ← update to your package name
        executable="sb2",         # field‑drawing executable
        name="drawing_node",
        parameters=[
            {"start_x": LaunchConfiguration("start_x")},
            {"start_y": LaunchConfiguration("start_y")},
            {"length":  LaunchConfiguration("length")},
            {"breadth": LaunchConfiguration("breadth")},
        ],
    )

    # 2) ploughing (brown fill)
    plough_node = Node(
        package="agribot",
        executable="sb3",
        name="plough_node",
        parameters=[
            {"start_x": LaunchConfiguration("start_x")},
            {"start_y": LaunchConfiguration("start_y")},
            {"length":  LaunchConfiguration("length")},
            {"breadth": LaunchConfiguration("breadth")},
        ],
    )

    # 3) seeding (pink dotted)
    sow_node = Node(
        package="agribot",
        executable="sb4",
        name="sow_node",
        parameters=[
            {"start_x": LaunchConfiguration("start_x")},
            {"start_y": LaunchConfiguration("start_y")},
            {"length":  LaunchConfiguration("length")},
            {"breadth": LaunchConfiguration("breadth")},
        ],
    )

    # 4) irrigation (blue)
    irrigation_node = Node(
        package="agribot",
        executable="sb5",
        name="irrigation_node",
        parameters=[
            {"start_x": LaunchConfiguration("start_x")},
            {"start_y": LaunchConfiguration("start_y")},
            {"length":  LaunchConfiguration("length")},
            {"breadth": LaunchConfiguration("breadth")},
        ],
    )

    # 5) harvesting (green solid)
    harvest_node = Node(
        package="agribot",
        executable="sb6",
        name="harvest_node",
        parameters=[
            {"start_x": LaunchConfiguration("start_x")},
            {"start_y": LaunchConfiguration("start_y")},
            {"length":  LaunchConfiguration("length")},
            {"breadth": LaunchConfiguration("breadth")},
        ],
    )

    # ── chained event handlers ────────────────────────────
    # field → plough
    start_plough_after_drawing = RegisterEventHandler(
        OnProcessExit(
            target_action=drawing_node,
            on_exit=[plough_node],
        )
    )

    # plough → seed
    start_sow_after_plough = RegisterEventHandler(
        OnProcessExit(
            target_action=plough_node,
            on_exit=[sow_node],
        )
    )

    # seed → irrigate
    start_irrigation_after_sow = RegisterEventHandler(
        OnProcessExit(
            target_action=sow_node,
            on_exit=[irrigation_node],
        )
    )

    # irrigate → harvest
    start_harvest_after_irrigation = RegisterEventHandler(
        OnProcessExit(
            target_action=irrigation_node,
            on_exit=[harvest_node],
        )
    )

    # ── assemble launch description ───────────────────────
    return LaunchDescription(
        [
            # launch arguments
            start_x_arg,
            start_y_arg,
            length_arg,
            breadth_arg,
            win_w_arg,
            win_h_arg,
            # environment
            set_win_w,
            set_win_h,
            # nodes & sequencing
            turtlesim_node,
            drawing_node,
            
            plough_node,
            sow_node,
            
        ]
    )
