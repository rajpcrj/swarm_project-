#!/usr/bin/env python3
import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.srv import SetPen, TeleportAbsolute
from turtlesim.msg import Pose   # ← pose feedback


class sb2(Node):
    def __init__(self):
        super().__init__("sb2")

        # publishers / clients
        self.publisher_ = self.create_publisher(Twist, "turtle1/cmd_vel", 10)
        self.pen_client = self.create_client(SetPen, "/turtle1/set_pen")
        self.teleport_client = self.create_client(
            TeleportAbsolute, "/turtle1/teleport_absolute"
        )
        # pose subscriber
        self.pose_x = 0.0
        self.pose_y = 0.0
        self.create_subscription(Pose, "turtle1/pose", self.pose_cb, 10)

        # wait for services
        while not self.pen_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info("Waiting for /turtle1/set_pen service…")
        while not self.teleport_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info("Waiting for /turtle1/teleport_absolute service…")

        # parameters
        self.declare_parameter("start_x", 2.0)
        self.declare_parameter("start_y", 2.0)
        self.declare_parameter("length", 5.0)
        self.declare_parameter("breadth", 4.0)

        self.start_x = float(self.get_parameter("start_x").value)
        self.start_y = float(self.get_parameter("start_y").value)
        self.length  = float(self.get_parameter("length").value)
        self.breadth = float(self.get_parameter("breadth").value)

        # colours
        self.bg_color = (69, 86, 255)         # unchanged background
        self.color    = (139, 69, 19)         # ← brown

        # jump to start
        self.change_pen_color(*self.bg_color, width=2, off=1)
        self.teleport_to(self.start_x, self.start_y)

        self.get_logger().info("Drawing filled rectangle …")
        self.control_turtle()

    # ── pose callback ────────────────────────────────────────────────────
    def pose_cb(self, msg: Pose):
        self.pose_x = msg.x
        self.pose_y = msg.y

    # ── helpers ──────────────────────────────────────────────────────────
    def teleport_to(self, x, y, theta=0.0):
        req = TeleportAbsolute.Request()
        req.x, req.y, req.theta = x, y, theta
        fut = self.teleport_client.call_async(req)
        rclpy.spin_until_future_complete(self, fut)

    def change_pen_color(self, r, g, b, width=4, off=0):
        req = SetPen.Request()
        req.r, req.g, req.b, req.width, req.off = r, g, b, 15, off
        fut = self.pen_client.call_async(req)
        rclpy.spin_until_future_complete(self, fut)

    def drive_to_x(self, target_x, speed, going_right):
        """Drive forward until we pass target_x (direction controlled by heading)."""
        twist = Twist()
        twist.linear.x = speed
        self.publisher_.publish(twist)

        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.01)
            reached = (going_right  and self.pose_x >= target_x) or \
                      (not going_right and self.pose_x <= target_x)
            if reached:
                break
            self.publisher_.publish(twist)

        twist.linear.x = 0.0
        self.publisher_.publish(twist)

    # ── main drawing logic ───────────────────────────────────────────────
    def control_turtle(self):
        speed        = 1.5
        num_lines    = 5
        line_spacing = 0.4#float(self.breadth) / num_lines
        current_y    = self.start_y

        for i in range(num_lines):
            going_right = (i % 2 == 0)

            heading  = 0.0 if going_right else math.pi          # face the way we’ll move
            start_x  = self.start_x if going_right else self.start_x + self.length
            target_x = self.start_x + self.length if going_right else self.start_x

            # jump to the start of this scan‑line (pen up)
            self.change_pen_color(*self.color, width=4, off=1)
            self.teleport_to(start_x, current_y, heading)

            # pen down, drive until pose_x crosses target_x
            self.change_pen_color(*self.color, width=1, off=0)
            self.drive_to_x(target_x, speed, going_right)

            # next horizontal strip
            current_y += line_spacing

        self.change_pen_color(*self.color, width=4, off=1)
        self.get_logger().info("Done filling rectangle.")

        # ── IMPORTANT: terminate cleanly so launch event fires ──
        rclpy.shutdown()                # triggers OnProcessExit

# ── entry point ─────────────────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = sb2()
    rclpy.spin(node)
    node.destroy_node()


if __name__ == "__main__":
    main()
