#!/usr/bin/env python3
import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.srv import SetPen, TeleportAbsolute
from turtlesim.msg import Pose


class sb2(Node):              # same executable name
    def __init__(self):
        super().__init__("sb2")

        # ── pubs / clients ───────────────────────────────────────
        self.cmd_pub       = self.create_publisher(Twist, "turtle1/cmd_vel", 10)
        self.pen_client    = self.create_client(SetPen, "/turtle1/set_pen")
        self.teleport_client = self.create_client(
            TeleportAbsolute, "/turtle1/teleport_absolute"
        )
        self.create_subscription(Pose, "turtle1/pose", self.pose_cb, 10)

        # wait for services
        for cli, name in [
            (self.pen_client, "/turtle1/set_pen"),
            (self.teleport_client, "/turtle1/teleport_absolute"),
        ]:
            while not cli.wait_for_service(timeout_sec=1.0):
                self.get_logger().info(f"Waiting for {name} service…")

        # ── parameters ───────────────────────────────────────────
        self.declare_parameter("start_x", 2.0)
        self.declare_parameter("start_y", 2.0)
        self.declare_parameter("length",  5.0)
        self.declare_parameter("breadth", 4.0)

        self.start_x = float(self.get_parameter("start_x").value)
        self.start_y = float(self.get_parameter("start_y").value)
        self.length  = float(self.get_parameter("length").value)
        self.breadth = float(self.get_parameter("breadth").value)

        # colours
        self.bg_color = (69, 86, 255)   # pen up “invisible” colour
        self.color    = (0, 255, 0)     # drawing colour

        # ── initialise pose and jump to start ───────────────────
        self.pose_x = 0.0
        self.pose_y = 0.0
        self.change_pen_color(*self.bg_color, width=0, off=1)
        self.teleport_to(self.start_x, self.start_y)

        # start drawing immediately
        self.get_logger().info("Drawing filled rectangle …")
        self.control_turtle()           # ← does all the work, then shuts down

    # ── pose callback ───────────────────────────────────────────
    def pose_cb(self, msg: Pose):
        self.pose_x = msg.x
        self.pose_y = msg.y

    # ── helpers ────────────────────────────────────────────────
    def teleport_to(self, x, y, theta=0.0):
        req = TeleportAbsolute.Request()
        req.x, req.y, req.theta = x, y, theta
        rclpy.spin_until_future_complete(self, self.teleport_client.call_async(req))

    def change_pen_color(self, r, g, b, width=0, off=0):
        req = SetPen.Request()
        req.r, req.g, req.b, req.width, req.off = r, g, b, width, off
        rclpy.spin_until_future_complete(self, self.pen_client.call_async(req))

    def drive_to_x(self, target_x, speed, going_right):
        """Drive until pose_x crosses target_x (direction set by heading)."""
        twist = Twist()
        twist.linear.x = speed
        self.cmd_pub.publish(twist)

        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.01)
            reached = (going_right and self.pose_x >= target_x) or \
                      (not going_right and self.pose_x <= target_x)
            if reached:
                break
            self.cmd_pub.publish(twist)

        twist.linear.x = 0.0
        self.cmd_pub.publish(twist)

    # ── main drawing logic ─────────────────────────────────────
    def control_turtle(self):
        speed        = 2.0
        num_lines    = 5
        line_spacing = 0.4#self.breadth / num_lines
        current_y    = self.start_y

        for i in range(num_lines):
            going_right = (i % 2 == 0)
            heading     = 0.0 if going_right else math.pi
            start_x     = self.start_x if going_right else self.start_x + self.length
            target_x    = self.start_x + self.length if going_right else self.start_x

            # pen up -> jump
            self.change_pen_color(*self.color, width=0, off=1)
            self.teleport_to(start_x, current_y, heading)

            # pen down -> draw scan‑line
            self.change_pen_color(*self.color, width=20, off=0)
            self.drive_to_x(target_x, speed, going_right)

            current_y += line_spacing

        self.change_pen_color(*self.color, width=0, off=1)
        self.get_logger().info("Done filling rectangle.")

        # ── IMPORTANT: terminate cleanly so launch event fires ──
        rclpy.shutdown()                # triggers OnProcessExit

# ── entry point ───────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = sb2()                        # executes drawing immediately
    # spin will unblock as soon as rclpy.shutdown() is called
    rclpy.spin(node)
    node.destroy_node()


if __name__ == "__main__":
    main()
