#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.srv import SetPen, TeleportAbsolute
from turtlesim.msg import Pose


class sb2(Node):                       # same executable name
    def __init__(self):
        super().__init__("sb2")

        # ── pubs / clients ────────────────────────────────────
        self.cmd_pub        = self.create_publisher(Twist, "turtle1/cmd_vel", 10)
        self.pen_client     = self.create_client(SetPen, "/turtle1/set_pen")
        self.teleport_client = self.create_client(
            TeleportAbsolute, "/turtle1/teleport_absolute"
        )
        self.create_subscription(Pose, "turtle1/pose", self.pose_cb, 10)

        for cli, name in [
            (self.pen_client, "/turtle1/set_pen"),
            (self.teleport_client, "/turtle1/teleport_absolute"),
        ]:
            while not cli.wait_for_service(timeout_sec=1.0):
                self.get_logger().info(f"Waiting for {name} service…")

        # ── parameters ───────────────────────────────────────
        self.declare_parameter("start_x", 2.0)
        self.declare_parameter("start_y", 2.0)
        self.declare_parameter("length",  5.0)
        self.declare_parameter("breadth", 4.0)

        self.start_x = float(self.get_parameter("start_x").value)
        self.start_y = float(self.get_parameter("start_y").value)
        self.length  = float(self.get_parameter("length").value)
        self.breadth = float(self.get_parameter("breadth").value)

        # colours
        self.bg_color = (69, 86, 255)   # “invisible” (pen up) colour
        self.color    = (0, 0, 255)     # BLUE drawing colour

        # ── initialise pose and jump to start ────────────────
        self.pose_x = 0.0
        self.pose_y = 0.0
        self.change_pen(*self.bg_color, width=0, off=1)
        self.teleport_to(self.start_x, self.start_y)

        # start drawing
        self.get_logger().info("Drawing filled rectangle with double‑dotted blue line …")
        self.control_turtle()

    # ── callbacks ───────────────────────────────────────────
    def pose_cb(self, msg: Pose):
        self.pose_x = msg.x
        self.pose_y = msg.y

    # ── convenience wrappers ───────────────────────────────
    def teleport_to(self, x, y, theta=0.0):
        req = TeleportAbsolute.Request(); req.x, req.y, req.theta = x, y, theta
        rclpy.spin_until_future_complete(self, self.teleport_client.call_async(req))

    def change_pen(self, r, g, b, width=0, off=0):
        req = SetPen.Request(); req.r, req.g, req.b, req.width, req.off = r, g, b, width, off
        rclpy.spin_until_future_complete(self, self.pen_client.call_async(req))

    # ── motion primitive (adds “double‑dots”) ───────────────
    def drive_to_x(self, target_x: float, speed: float, going_right: bool):
        """
        Move straight until pose_x crosses target_x while stamping a
        repeating   dot‑dot / gap   pattern:  • •   • •   • • …
        """
        # pattern distances (in simulator units)
        DOT_LEN     = 0.008    # length of each individual dot
        DOT_GAP     = 0.008    # small gap between the two dots in a pair
        GROUP_GAP   = 0.25    # gap before the next double‑dot pair
        SEGMENTS    = [DOT_LEN, DOT_GAP, DOT_LEN, GROUP_GAP]  # repeat forever

        seg_idx      = 0                  # which segment we’re in
        next_toggle  = SEGMENTS[0]        # distance at which to toggle pen
        pen_down     = True               # we start with the pen *down*
        start_x      = self.pose_x

        self.change_pen(*self.color, width=6, off=0)  # pen down for first dot
        twist = Twist(); twist.linear.x = speed
        self.cmd_pub.publish(twist)

        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.01)

            # stop when we’ve reached / passed the target
            reached = (going_right and self.pose_x >= target_x) or \
                      (not going_right and self.pose_x <= target_x)
            if reached:
                break

            # distance travelled so far on this scan‑line
            travelled = abs(self.pose_x - start_x)
            if travelled >= next_toggle:
                # toggle pen state
                pen_down = not pen_down
                self.change_pen(*self.color, width=6, off=int(not pen_down))

                # advance to next segment in the pattern
                seg_idx = (seg_idx + 1) % len(SEGMENTS)
                next_toggle += SEGMENTS[seg_idx]

            self.cmd_pub.publish(twist)

        # stop motion & lift pen
        twist.linear.x = 0.0; self.cmd_pub.publish(twist)
        if pen_down:
            self.change_pen(*self.color, width=6, off=1)

    # ── main drawing logic (unchanged except width) ─────────
    def control_turtle(self):
        speed        = 2.0
        num_lines    = 5
        line_spacing = 0.4
        current_y    = self.start_y

        for i in range(num_lines):
            going_right = (i % 2 == 0)

            heading     = 0.0 if going_right else math.pi
            start_x     = self.start_x if going_right else self.start_x + self.length
            target_x    = self.start_x + self.length if going_right else self.start_x

            # jump to new row (pen up)
            self.change_pen(*self.bg_color, width=0, off=1)
            self.teleport_to(start_x, current_y, heading)

            # draw scan‑line with dotted pattern
            self.drive_to_x(target_x, speed, going_right)

            current_y += line_spacing

        self.change_pen(*self.bg_color, width=0, off=1)
        self.get_logger().info("Done filling rectangle.")

        # terminate cleanly so launch event fires
        rclpy.shutdown()

# ── entry point ────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = sb2()
    rclpy.spin(node)
    node.destroy_node()


if __name__ == "__main__":
    main()
