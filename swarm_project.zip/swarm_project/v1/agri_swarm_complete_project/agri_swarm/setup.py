from setuptools import setup

package_name = 'agri_swarm'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/' + package_name + '/launch', ['launch/farm_sim.launch.py']),
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user',
    maintainer_email='user@example.com',
    description='Swarm simulation using turtlesim for agricultural tasks',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'spawner = agri_swarm.spawner:main',
            'seeder = agri_swarm.seeder:main',
            'soil_detector = agri_swarm.soil_detector:main',
            'irrigator = agri_swarm.irrigator:main',
            'harvester = agri_swarm.harvester:main',
        ],
    },
)