from turtlesim.srv import SetPen
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import math
# ... (other imports same as above)

class IrrigatorNode(Node):
    def __init__(self):
        super().__init__('irrigator_node')
        self.vel_pub = self.create_publisher(Twist, 'irrigator/cmd_vel', 10)
        self.status_pub = self.create_publisher(String, 'irrigator/status', 10)
        self.create_subscription(Pose, 'irrigator/pose', self.pose_callback, 10)
        self.create_subscription(Pose, 'soil/pose', self.leader_pose_callback, 10)
        self.pose = Pose()
        self.leader_pose = None
        self.safe_distance = 1.0
        # Change pen color to blue for water representation
        self.pen_client = self.create_client(SetPen, 'irrigator/set_pen')
        if self.pen_client.wait_for_service(timeout_sec=1.0):
            pen_req = SetPen.Request(r=0, g=0, b=255, width=2, off=0)
            self.pen_client.call_async(pen_req)
        # Timer for movement
        self.timer = self.create_timer(0.1, self.control_loop)

    def pose_callback(self, msg):
        self.pose = msg

    def leader_pose_callback(self, msg):
        self.leader_pose = msg

    def control_loop(self):
        twist = Twist()
        # Formation spacing: maintain distance from soil detector
        if self.leader_pose:
            dx = self.leader_pose.x - self.pose.x
            dy = self.leader_pose.y - self.pose.y
            dist = (dx*dx + dy*dy) ** 0.5
            if dist < self.safe_distance:
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.vel_pub.publish(twist)
                return
        # Normal movement (follow path)
        twist.linear.x = 2.0
        twist.angular.z = 0.0
        # We can optionally check for boundaries and implement turning similar to seeder (omitted for brevity)
        # Publish watering status occasionally
        if int(self.pose.x) % 3 == 0:  # e.g., every 3 units in X, just as a simple condition
            status_msg = String(data=f"Irrigator: Watering at ({self.pose.x:.1f}, {self.pose.y:.1f})")
            self.status_pub.publish(status_msg)
        self.vel_pub.publish(twist)

# main() function omitted for brevity (same pattern as above)
def main(args=None):
    rclpy.init(args=args)
    node = IrrigatorNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()