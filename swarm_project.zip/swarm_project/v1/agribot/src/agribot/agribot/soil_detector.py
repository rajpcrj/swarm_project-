from turtlesim.srv import SetPen
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import math
import random

class SoilDetectorNode(Node):
    def __init__(self):
        super().__init__('soil_detector_node')
        self.vel_pub = self.create_publisher(Twist, 'soil/cmd_vel', 10)
        self.status_pub = self.create_publisher(String, 'soil/status', 10)
        self.create_subscription(Pose, 'soil/pose', self.pose_callback, 10)
        self.create_subscription(Pose, 'seeder/pose', self.leader_pose_callback, 10)
        self.pose = Pose()
        self.seeder_pose = None
        # Control parameters
        self.safe_distance = 1.0   # minimum distance to maintain from seeder
        self.sampling_interval = 5.0  # seconds between soil samples
        self.sampling_timer = 0.0
        self.sampling_duration = 2.0  # time to pause for a sample
        self.is_sampling = False
        # Timer for movement control
        self.timer = self.create_timer(0.1, self.control_loop)  # 10 Hz

    def pose_callback(self, msg):
        self.pose = msg

    def leader_pose_callback(self, msg):
        self.seeder_pose = msg

    def control_loop(self):
        
        twist = Twist()
        if self.is_sampling:
            # Remain stopped
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            # After a certain time, end sampling
            self.sampling_timer += 0.1
            if self.sampling_timer >= self.sampling_duration:
                self.is_sampling = False
                self.sampling_timer = 0.0
                self.get_logger().info("Soil sampling complete, resuming movement.")
            else:
                # Still in sampling period
                self.vel_pub.publish(twist)
                return

        # Formation spacing: check distance to seeder
        if self.seeder_pose:
            dx = self.seeder_pose.x - self.pose.x
            dy = self.seeder_pose.y - self.pose.y
            dist = (dx**2 + dy**2) ** 0.5
            if dist < self.safe_distance:
                # Too close to leader - stop to maintain spacing
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.vel_pub.publish(twist)
                return

        # Boundary handling: similar to seeder (follow same row-turn pattern)
        # (We can reuse logic: if at edge, turn, etc. Here for brevity, assume seeder will guide path; 
        # the follower will naturally turn when it reaches the same boundary due to its orientation.)
        # For simplicity, we won't explicitly program turning here – turtle will eventually turn by following orientation or we could copy seeder's orientation.

        # Normal forward movement
        twist.linear.x = 2.0  # same speed as seeder when moving
        twist.angular.z = 0.0

        # Decide if it's time to take a soil sample
        self.sampling_timer += 0.1
        if self.sampling_timer >= self.sampling_interval:
            # Time to sample soil: stop and report
            self.is_sampling = True
            self.sampling_timer = 0.0
            twist.linear.x = 0.0
            # Choose a random soil type
            soil_types = ['loam', 'clay', 'sand', 'silt']
            soil_type = random.choice(soil_types)
            msg = f"SoilDetector: Sampled soil at (x={self.pose.x:.1f}, y={self.pose.y:.1f}) -> {soil_type}"
            self.status_pub.publish(String(data=msg))
            self.get_logger().info(msg)
            # (Stay stopped for the next few cycles to simulate analysis time)
        self.vel_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = SoilDetectorNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
