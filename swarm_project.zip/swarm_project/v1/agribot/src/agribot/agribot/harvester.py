from turtlesim.srv import SetPen
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import math


class HarvesterNode(Node):
    def __init__(self):
        super().__init__('harvester_node')
        self.vel_pub = self.create_publisher(Twist, 'harvester/cmd_vel', 10)
        self.status_pub = self.create_publisher(String, 'harvester/status', 10)
        self.create_subscription(Pose, 'harvester/pose', self.pose_callback, 10)
        self.create_subscription(Pose, 'irrigator/pose', self.leader_pose_callback, 10)
        self.pose = Pose()
        self.leader_pose = None
        self.safe_distance = 1.0
        self.timer = self.create_timer(0.1, self.control_loop)
        self.last_msg_time = 0.0

    def pose_callback(self, msg):
        self.pose = msg

    def leader_pose_callback(self, msg):
        self.leader_pose = msg

    def control_loop(self):
        twist = Twist()
        # Maintain formation distance
        if self.leader_pose:
            dx = self.leader_pose.x - self.pose.x
            dy = self.leader_pose.y - self.pose.y
            if (dx*dx + dy*dy) ** 0.5 < self.safe_distance:
                twist.linear.x = 0.0
                self.vel_pub.publish(twist)
                return
        # Otherwise move forward
        twist.linear.x = 2.0
        twist.angular.z = 0.0
        # Example status message periodically
        self.last_msg_time += 0.1
        if self.last_msg_time >= 3.0:  # every 3 seconds
            status = String(data=f"Harvester: Harvesting at ({self.pose.x:.1f}, {self.pose.y:.1f})")
            self.status_pub.publish(status)
            self.last_msg_time = 0.0
        self.vel_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = HarvesterNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()