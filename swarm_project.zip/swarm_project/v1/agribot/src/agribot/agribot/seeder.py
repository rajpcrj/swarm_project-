import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import math

class SeederNode(Node):
    def __init__(self):
        super().__init__('seeder_node')
        self.pose = Pose()
        self.vel_pub = self.create_publisher(Twist, 'seeder/cmd_vel', 10)
        self.status_pub = self.create_publisher(String, 'seeder/status', 10)
        self.create_subscription(Pose, 'seeder/pose', self.pose_callback, 10)

        self.timer = self.create_timer(0.1, self.control_loop)

        # State variables
        self.state = 'MOVE_RIGHT'
        self.row_direction = 1 # 1 = right, -1 = left
        self.target_y = 10.5
        self.drop_interval = 2.0
        self.last_drop_x = None
        self.rows_completed = 0
        self.max_rows = 5 # controls how many rows to traverse
        self.row_height = 1.5
        self.turning = False
        self.turn_start_angle = 0.0

    def pose_callback(self, msg):
        self.pose = msg

    def control_loop(self):
        twist = Twist()

        if self.state in ['MOVE_RIGHT', 'MOVE_LEFT']:
            if self.row_direction == 1 and self.pose.x > 10.5:
                self.state = 'TURN_DOWN_1'
                self.turn_start_angle = self.pose.theta
            elif self.row_direction == -1 and self.pose.x < 0.5:
                self.state = 'TURN_DOWN_1'
                self.turn_start_angle = self.pose.theta
            else:
                twist.linear.x = 2.0
                twist.angular.z = 0.0
                if self.last_drop_x is None or abs(self.pose.x - self.last_drop_x) > self.drop_interval:
                    msg = String()
                    msg.data = f"Seeder: Dropping seed at ({self.pose.x:.1f}, {self.pose.y:.1f})"
                    self.status_pub.publish(msg)
                    self.last_drop_x = self.pose.x

        elif self.state == 'TURN_DOWN_1':
            twist.linear.x = 0.0
            twist.angular.z = -1.57
            if abs(self.pose.theta - (self.turn_start_angle - 1.57)) < 0.1:
                self.state = 'MOVE_DOWN'

        elif self.state == 'MOVE_DOWN':
            twist.linear.x = 2.0
            twist.angular.z = 0.0
            if self.pose.y < self.target_y - self.row_height:
                self.state = 'TURN_DOWN_2'
                self.turn_start_angle = self.pose.theta

        elif self.state == 'TURN_DOWN_2':
            twist.linear.x = 0.0
            twist.angular.z = -1.57
            if abs(self.pose.theta - (self.turn_start_angle - 1.57)) < 0.1:
                self.row_direction *= -1
                self.state = 'MOVE_RIGHT' if self.row_direction == 1 else 'MOVE_LEFT'
                self.rows_completed += 1
                self.target_y = self.pose.y
                if self.rows_completed >= self.max_rows:
                    self.state = 'STOP'
                    self.status_pub.publish(String(data="Seeder: Farming done"))
                    self.get_logger().info("Seeder: Farming done.")

        elif self.state == 'STOP':
            twist.linear.x = 0.0
            twist.angular.z = 0.0

        self.vel_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = SeederNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()