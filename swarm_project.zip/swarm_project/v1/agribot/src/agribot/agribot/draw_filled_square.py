import rclpy
from rclpy.node import Node
from turtlesim.srv import TeleportAbsolute, SetPen
from geometry_msgs.msg import Twist
import time

class DrawFilledSquare(Node):
    def __init__(self):
        super().__init__('draw_filled_square')
        self.cli_teleport = self.create_client(TeleportAbsolute, '/sim/teleport_absolute')
        self.cli_pen = self.create_client(SetPen, '/sim/set_pen')
        self.timer = self.create_timer(2.0, self.draw_filled_square)
        self.done = False

    def draw_filled_square(self):
        if self.done:
            return

        if not (self.cli_teleport.service_is_ready() and self.cli_pen.service_is_ready()):
            self.get_logger().info('Waiting for services...')
            return

        x_min, x_max = 2.0, 5.0
        y_min, y_max = 2.0, 5.0
        y_step = 0.1

        self.set_pen(0, 255, 0, 2, 0)  # Green pen, 2px

        y = y_min
        toggle = True

        while y <= y_max:
            if toggle:
                self.teleport(x_min, y)
                self.sleep()
                self.move_to(x_max)
            else:
                self.teleport(x_max, y)
                self.sleep()
                self.move_to(x_min)

            y += y_step
            toggle = not toggle

        self.set_pen(0, 0, 0, 0, 1)  # Pen off
        self.done = True

    def teleport(self, x, y):
        req = TeleportAbsolute.Request()
        req.x = x
        req.y = y
        req.theta = 0.0
        future = self.cli_teleport.call_async(req)
        rclpy.spin_until_future_complete(self, future)

    def set_pen(self, r, g, b, width, off):
        req = SetPen.Request()
        req.r = r
        req.g = g
        req.b = b
        req.width = width
        req.off = off
        future = self.cli_pen.call_async(req)
        rclpy.spin_until_future_complete(self, future)

    def move_to(self, x_target):
        # Slow straight movement along x
        pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        msg = Twist()
        msg.linear.x = 1.0 if x_target > 0 else -1.0
        distance = abs(x_target - 2.0)
        duration = abs(x_target - 2.0) / 1.0
        pub.publish(msg)
        time.sleep(duration)
        msg.linear.x = 0.0
        pub.publish(msg)

    def sleep(self):
        time.sleep(0.1)

def main():
    rclpy.init()
    node = DrawFilledSquare()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
