from turtlesim.srv import SetPen
import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import math
from turtlesim.srv import Kill, Spawn


class Spawner(Node):
    def __init__(self):
        super().__init__('spawner')
        # Wait for necessary services to be available
        self.kill_client = self.create_client(Kill, 'kill')
        self.spawn_client = self.create_client(Spawn, 'spawn')
        while not self.kill_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /kill service...')
        while not self.spawn_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /spawn service...')

        # 1. Kill the default turtle (turtle1) to start fresh
        kill_req = Kill.Request()
        kill_req.name = 'turtle1'
        self.kill_client.call_async(kill_req)

        # 2. Spawn our four turtles with unique names and positions
        spawn_positions = [
            ('seeder',    4.0, 10.0, 0.0),
            ('soil',      2.5, 10.0, 0.0),
            ('irrigator', 1.0, 10.0, 0.0),
            ('harvester', 0.5, 10.0, 0.0),
        ]
        for name, x, y, theta in spawn_positions:
            req = Spawn.Request()
            req.name = name
            req.x, req.y, req.theta = x, y, theta
            self.spawn_client.call_async(req)
            self.get_logger().info(f"Spawned turtle: {name} at ({x}, {y}).")

        # Optional: we could also set pen colors for each turtle here by calling /<name>/set_pen service.
        # For example, set irrigator's pen to blue, seeder's to white, etc., to differentiate trails.
        # (This can also be done in each node after spawn.)
        self.get_logger().info("Spawner node finished spawning turtles.")

def main(args=None):
    rclpy.init(args=args)
    node = Spawner()
    # Give some time for spawn requests to complete
    rclpy.spin_once(node, timeout_sec=2)
    node.destroy_node()
    rclpy.shutdown()
