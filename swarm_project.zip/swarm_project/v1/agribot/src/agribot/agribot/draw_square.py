# draw_square.py
import rclpy
from rclpy.node import Node
from turtlesim.srv import TeleportAbsolute
from turtlesim.srv import SetPen
from geometry_msgs.msg import Twist
import time

class DrawSquare(Node):
    def __init__(self):
        super().__init__('draw_square')
        self.cli_teleport = self.create_client(TeleportAbsolute, '/turtle1/teleport_absolute')
        self.cli_pen = self.create_client(SetPen, '/turtle1/set_pen')
        self.pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)

        self.timer = self.create_timer(2.0, self.draw_square)  # Delay a bit after start
        self.done = False

    def draw_square(self):
        if self.done:
            return

        if not (self.cli_teleport.service_is_ready() and self.cli_pen.service_is_ready()):
            self.get_logger().info('Waiting for services...')
            return

        self.set_pen(255, 255, 255, 5, 0)  # Green pen, width 5
        self.teleport(2.0, 2.0)

        commands = [
            (3.0, 0.0),  # right
            (0.0, 3.0),  # up
            (-3.0, 0.0), # left
            (0.0, -3.0)  # down
        ]

        for dx, dy in commands:
            twist = Twist()
            twist.linear.x = dx
            twist.linear.y = dy
            self.pub.publish(twist)
            time.sleep(0.5)

        self.set_pen(0, 0, 0, 0, 1)  # Pen off
        self.done = True

    def teleport(self, x, y):
        req = TeleportAbsolute.Request()
        req.x = float(x)
        req.y = float(y)
        req.theta = 0.0
        self.cli_teleport.call_async(req)

    def set_pen(self, r, g, b, width, off):
        req = SetPen.Request()
        req.r = r
        req.g = g
        req.b = b
        req.width = width
        req.off = off
        self.cli_pen.call_async(req)

def main():
    rclpy.init()
    node = DrawSquare()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
