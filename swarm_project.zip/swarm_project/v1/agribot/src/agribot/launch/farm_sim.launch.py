from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # Set background color to a brownish tone (e.g., r=160, g=130, b=70)
    return LaunchDescription([
        Node(package='turtlesim', executable='turtlesim_node', name='sim',
             parameters=[{'background_r': 160, 'background_g': 130, 'background_b': 70}], 
             output='screen'),
          Node(
            package='turtlesim',
            executable='turtlesim_node',
            namespace='sim2',
            parameters=[{'background_r': 70, 'background_g': 160, 'background_b': 130}],
            output='screen'
        ),
        Node(
            package='turtlesim',
            executable='turtle_teleop_key',
            name='teleop_turtle2',
            namespace='sim2',
            output='screen'
        ),
       
        Node(package='agribot',executable='draw_square',name='draw_square'),
        Node(package='agribot', executable='spawner', output='screen'),
        Node(package='agribot', executable='seeder',  output='screen'),
        Node(package='agribot', executable='soil_detector',  output='screen'),
        Node(package='agribot', executable='irrigator',  output='screen'),
        Node(package='agribot', executable='harvester',  output='screen'),
        #Node(package='agribot', executable= 'color_filler', output= 'screen'),
    ])

