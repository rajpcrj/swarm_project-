from setuptools import find_packages, setup

package_name = 'agribot'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/farmswarm.launch.py']),  # Updated launch file path
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='raj',
    maintainer_email='rajpcrj@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'sb1 = agribot.sb1:main',  # Entry point for the sb1 node
            'sb2 = agribot.sb2:main',
            'spawn_turtle = agribot.spawn_turtle:main',
            'sb3 = agribot.sb3:main',
            'sb4 = agribot.sb4:main',
            'sb5 = agribot.sb5:main',
            
            'test_listner = agribot.test_listner:main',
        ],
    },
)
