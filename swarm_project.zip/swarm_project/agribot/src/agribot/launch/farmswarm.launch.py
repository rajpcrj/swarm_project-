import launch
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable, TimerAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # Declare launch arguments for drawing parameters
        DeclareLaunchArgument('start_x', default_value='2.0'),
        DeclareLaunchArgument('start_y', default_value='2.0'),
        DeclareLaunchArgument('length', default_value='5.0'),
        DeclareLaunchArgument('breadth', default_value='3.0'),

        # Declare launch arguments for parent turtle (default to 'turtle1')
        DeclareLaunchArgument('parent_turtle_name_1', default_value='turtle1'),
        DeclareLaunchArgument('parent_turtle_name_2', default_value='turtle2'),
        DeclareLaunchArgument('parent_turtle_name_3', default_value='turtle3'),
        DeclareLaunchArgument('parent_turtle_name_4', default_value='turtle4'),
        DeclareLaunchArgument('parent_turtle_name_5', default_value='turtle5'),



        # Turtlesim node with 10Hz update rate
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='turtlesim_node',
            parameters=[{'update_rate': 10.0}]
        ),

        # Spawn first turtle after a short delay

        Node(
            package='agribot',
            executable='sb2',
            name='sb2_node',
            parameters=[
                {'start_x': LaunchConfiguration('start_x')},
                {'start_y': LaunchConfiguration('start_y')},
                {'length': LaunchConfiguration('length')},
                {'breadth': LaunchConfiguration('breadth')},
                  # Ensure this node knows the parent
            ]
        ),

        Node(
            package='agribot',
            executable='spawn_turtle',
            name='spawn_turtle_node',
            output='screen',
            parameters=[
                {'start_x': LaunchConfiguration('start_x')},
                {'start_y': LaunchConfiguration('start_y')},
                {'length': LaunchConfiguration('length')},
                {'breadth': LaunchConfiguration('breadth')},
                {'parent_turtle_name': LaunchConfiguration('parent_turtle_name_1')},
            ]
        ),

        Node(
            package='agribot',
            executable='sb3',
            name='sb3',
            output='screen',
            parameters=[
                {'start_x': LaunchConfiguration('start_x')},
                {'start_y': LaunchConfiguration('start_y')},
                {'length': LaunchConfiguration('length')},
                {'breadth': LaunchConfiguration('breadth')},
                {'parent_turtle_name': LaunchConfiguration('parent_turtle_name_1')},
            ]
        ),
        Node(
            package='agribot',
            executable='sb4',
            name='sb4',
            output='screen',
            parameters=[
                {'start_x': LaunchConfiguration('start_x')},
                {'start_y': LaunchConfiguration('start_y')},
                {'length': LaunchConfiguration('length')},
                {'breadth': LaunchConfiguration('breadth')},
                {'parent_turtle_name': LaunchConfiguration('parent_turtle_name_1')},
            ]
        ),

        Node(
            package='agribot',
            executable='sb5',
            name='sb5',
            output='screen',
            parameters=[
                {'start_x': LaunchConfiguration('start_x')},
                {'start_y': LaunchConfiguration('start_y')},
                {'length': LaunchConfiguration('length')},
                {'breadth': LaunchConfiguration('breadth')},
                {'parent_turtle_name': LaunchConfiguration('parent_turtle_name_1')},
            ]
        ),

       
       
            
        

        # Drawing node with parent turtle information
        
    ])
