#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.srv import SetPen, TeleportAbsolute
from turtlesim.msg import Pose
from std_msgs.msg import String
import json
import time
import threading

class sb2(Node):
    def __init__(self):
        super().__init__('sb2')

        self.publisher_ = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        

        self.pen_client = self.create_client(SetPen, '/turtle1/set_pen')
        self.teleport_client = self.create_client(TeleportAbsolute, '/turtle1/teleport_absolute')

        self.create_subscription(Pose, 'turtle1/pose', self.pose_callback, 10)
        self.special_message_publisher = self.create_publisher(String, 'turtle1_special_message', 10)

        while not self.pen_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /turtle1/set_pen service...')
        while not self.teleport_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /turtle1/teleport_absolute service...')

        self.declare_parameter('start_x', 2.0)
        self.declare_parameter('start_y', 2.0)
        self.declare_parameter('length', 5.0)
        self.declare_parameter('breadth', 3.0)

        self.start_x = self.get_parameter('start_x').value
        self.start_y = self.get_parameter('start_y').value
        self.length = self.get_parameter('length').value
        self.breadth = self.get_parameter('breadth').value

        self.bg_color = (194, 178, 128)
        self.color = (0, 255, 0)

        self.position = [self.start_x, self.start_y]
        self.velocity = [0.0, 0.0]
        self.line_number = 0
        #self.current_pos = {'x': self.start_x, 'y': self.start_y}
        self.current_pos = [0,0]

        self.change_pen_color(*self.bg_color, width=5, off=1)
        self.teleport_to(self.start_x, self.start_y)

        # Timer for publishing special message at 10Hz
        #self.create_timer(0.01, self.send_special_message)
        

        self.control_executed = False
        

        self.get_logger().info('Drawing filled rectangle...')
        self.control_turtle()

    def pose_callback(self, msg):
        self.current_pos[0] = msg.x
        self.current_pos[1] = msg.y

    def send_special_message(self):
        
        #self.pose_callback()
        message_data = {
            "position": {"x": self.current_pos[0], "y": self.current_pos[1]},
            "velocity": {"linear_x": self.velocity[0], "linear_y": self.velocity[1]},
            "line_number": self.line_number
        }
        msg = String()
        msg.data = json.dumps(message_data)
        self.special_message_publisher.publish(msg)

        
        #self.get_logger().info('Sent message is '+ str(msg))

    def teleport_to(self, x, y):
        request = TeleportAbsolute.Request()
        request.x = x
        request.y = y
        request.theta = 0.0
        future = self.teleport_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

    def change_pen_color(self, r, g, b, width=5, off=0):
        request = SetPen.Request()
        request.r = r
        request.g = g
        request.b = b
        request.width = width
        request.off = off
        future = self.pen_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

    def drive_to_x(self, target_x, speed, going_right):
        """Drive until pose_x crosses target_x (direction set by heading)."""
        twist = Twist()
        twist.linear.x = speed
        self.publisher_.publish(twist)

        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.01)
            reached = (going_right and self.pose_x >= target_x) or \
                      (not going_right and self.pose_x <= target_x)
            if reached:
                break
            self.publisher_.publish(twist)

        twist.linear.x = 0.0
        self.publisher_.publish(twist)

    def control_turtle(self):
        speed = 2.0
        line_duration = self.length / speed
        line_spacing = self.breadth / 10.0
        num_lines = 10
        self.teleport_to(self.start_x,self.start_y)

        self.change_pen_color(*self.color, width=20, off=0)

        for i in range(num_lines):
            self.line_number = i
            k=0
            message_data = {
            "position": {"x": self.current_pos[0], "y": self.current_pos[1]},
            "velocity": {"linear_x": self.velocity[0], "linear_y": self.velocity[1]},
            "line_number": self.line_number
            }
            msg = String()
            msg.data = json.dumps(message_data)

            # Forward line
            twist = Twist()
            twist.linear.x = speed
            self.velocity = [speed, 0.0]
            self.publisher_.publish(twist)
            k=0
            while(k<10*line_duration):
                time.sleep(0.1)
                #self.send_special_message()
                k+=1

            twist.linear.x = 0.0
            self.velocity = [0.0, 0.0]
            self.publisher_.publish(twist)
            #self.special_message_publisher.publish(msg)
            self.get_logger().info("R1")

            # Lift pen and move up
            self.change_pen_color(*self.color, width=20, off=1)
            twist = Twist()
            twist.linear.y = line_spacing
            self.velocity = [0.0, line_spacing]
            self.publisher_.publish(twist)
            k=0
            time.sleep(1)
            twist.linear.y = 0.0
            self.velocity = [0.0, 0.0]
            self.publisher_.publish(twist)
            #self.special_message_publisher.publish(msg)

            # Reverse line
            self.change_pen_color(*self.color, width=20, off=0)
            twist = Twist()
            twist.linear.x = -speed
            self.velocity = [-speed, 0.0]
            self.publisher_.publish(twist)
            k=0
            while(k<10*line_duration):
                time.sleep(0.1)
                #self.send_special_message()
                k+=1
            twist.linear.x = 0.0
            self.velocity = [0.0, 0.0]
            self.publisher_.publish(twist)
            #self.special_message_publisher.publish(msg)

            # Move up again
            self.change_pen_color(*self.color, width=20, off=1)
            twist = Twist()
            twist.linear.y = line_spacing
            self.velocity = [0.0, line_spacing]
            self.publisher_.publish(twist)
            k=0
            time.sleep(1)
            twist.linear.y = 0.0
            self.velocity = [0.0, 0.0]
            self.publisher_.publish(twist)
            #self.special_message_publisher.publish(msg)


            self.special_message_publisher.publish(msg)

            self.change_pen_color(*self.color, width=20, off=0)
 
            self.get_logger().info("Current Line is  " + str(i)+ " KKKKKKKKKKKKKpppppppppp")
            self.get_logger().info("Published message is  "+ str(msg) +"KKKKKKKKKKKKKpppppppppp")
            self.send_special_message()
        

def main(args=None):
    rclpy.init(args=args)
    node = sb2()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
