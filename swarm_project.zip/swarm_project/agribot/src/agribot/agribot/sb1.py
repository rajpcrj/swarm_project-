# sb1.py

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import sys
import termios
import tty
import random
from turtlesim.srv import SetPen

class sb1(Node):
    
    def __init__(self):
        super().__init__('sb1')  # Name of the node is 'sb1'
        self.publisher_ = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        self.pen_client = self.create_client(SetPen, '/turtle1/set_pen')
        while not self.pen_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /turtle1/set_pen service...')
        self.get_logger().info('Teleop Turtle started. Use WASD keys to control the turtle.')
        self.color= (0,255,0)
        self.control_turtle()

        
        
        self.get_logger().info('The current color is .'+ str(self.color))

    def control_turtle(self):
        # Set up the control keys and speed
        speed = 1.0
        turn = 1.0

        while rclpy.ok():
            key = self.get_key()
            twist = Twist()

            # Control turtle movement with WASD
            if key == 'w':
                twist.linear.x = speed
            elif key == 's':
                twist.linear.x = -speed
            elif key == 'a':
                twist.angular.z = speed
            elif key == 'd':
                twist.angular.z = -speed
            elif key == 'q':
                break  # Exit on 'q'
            elif key=='c':
                self.color= self.generate_color()

            else:
                twist.linear.x = 0.00
                twist.angular.z = 0.00

            self.publisher_.publish(twist)
            self.get_logger().info(f'Key pressed: {key}')

    def get_key(self):
        # Use terminal to read a single key press
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch
    
    def generate_color(self):
        # Generate random RGB values
        red = random.randint(0, 255)
        green = random.randint(0, 255)
        blue = random.randint(0, 255)
        self.get_logger().info('Current color changed to  .'+ str(self.color))
        
        # Create request
        request = SetPen.Request()
        request.r = red
        request.g = green
        request.b = blue
        request.width = 3
        request.off = 0  # 0 = pen on, 1 = pen off

        # Call the service
        future = self.pen_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        self.get_logger().info('Current color changed to: ' + str(self.color))
        return self.color

def main(args=None):
    rclpy.init(args=args)
    node = sb1()  # Initialize 'sb1' node
    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
