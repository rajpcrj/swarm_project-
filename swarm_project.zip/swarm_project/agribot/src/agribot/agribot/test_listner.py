import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import json

class TestListener(Node):
    def __init__(self):
        super().__init__('test_listener')
        self.get_logger().info("Initializing Test Listener...")
        self.subscribers = []
        self.create_timer(2.0, self.discover_special_message_topics)

    def discover_special_message_topics(self):
        topic_list = self.get_topic_names_and_types()
        for topic, types in topic_list:
            if 'special_message' in topic and topic not in [sub.topic_name for sub in self.subscribers]:
                if 'std_msgs/msg/String' in types or 'std_msgs/msg/String' in [t.replace('.', '/').lower() for t in types]:
                    self.get_logger().info(f"Subscribing to: {topic}")
                    sub = self.create_subscription(String, topic, self.special_message_callback_factory(topic), 10)
                    sub.topic_name = topic  # store topic name for later filtering
                    self.subscribers.append(sub)

    def special_message_callback_factory(self, topic_name):
        def callback(msg):
            try:
                data = json.loads(msg.data)
                self.get_logger().info(f"[{topic_name}] Received: {json.dumps(data, indent=2)}")
            except json.JSONDecodeError:
                self.get_logger().warn(f"[{topic_name}] Received non-JSON message: {msg.data}")
        return callback


def main(args=None):
    rclpy.init(args=args)
    node = TestListener()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
