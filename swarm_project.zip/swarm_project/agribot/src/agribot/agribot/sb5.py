#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from turtlesim.srv import Spawn, TeleportAbsolute
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
from std_msgs.msg import String
import json
import time
from turtlesim.srv import SetPen
import subprocess

class sb4(Node):
    def __init__(self):
        super().__init__('sb4')
        # PARAMETER DECLARATIONS 
        self.req = Spawn.Request()
        self.declare_parameter('start_x', 2.0)
        self.declare_parameter('start_y', 2.0)
        self.declare_parameter('offset_x', 2.0)
        self.declare_parameter('offset_y', 2.0)

        self.start_x = self.get_parameter('start_x').value
        self.start_y = self.get_parameter('start_y').value
        self.offset_x = self.get_parameter('offset_x').value
        self.offset_y = self.get_parameter('offset_y').value

        self.get_logger().info("Parameters are "+ str(self.start_x) +" "+ str(self.start_y)+" LOL")

        self.req.x = self.start_x 
        self.req.y = self.start_y 
        self.req.theta = 0.0
        self.req.name = 'turtle5'
        # END 
        # SOME MORE VARIABLE DECLARATIOSN 
        self.position = [self.start_x, self.start_y]
        self.velocity = [0.0, 0.0]
        self.line_number = 0
        #self.current_pos = {'x': self.start_x, 'y': self.start_y}
        self.current_pos = [0,0]

        
        # CLIENT_CLASSES
        self.cli = self.create_client(Spawn, 'spawn')
        self.pen_client = self.create_client(SetPen, "/turtle5/set_pen")
        self.teleport_client = self.create_client(TeleportAbsolute, '/turtle5/teleport_absolute')
        ## These are the subscription classes 
        self.pose_subscriber = self.create_subscription(Pose, '/turtle4/pose', self.pose_callback, 10)
        self.special_message_subscriber = self.create_subscription(String, '/turtle4_special_message', self.special_message_callback, 1)


        # these are the publisher classes 
        self.special_message_publisher = self.create_publisher(String, 'turtle5_special_message', 10)
        self.publisher_ = self.create_publisher(Twist, 'turtle5/cmd_vel', 10)
        #self.publisher_ = self.create_publisher(Twist, 'turtle2/cmd_vel', 10)

        # STARTING THE NODES 

        
        
        
        
        # Colors

        self.bg_color = (194, 178, 128)
        self.color    = (0, 0, 255) 
        


        self.future = self.cli.call_async(self.req)
        self.future.add_done_callback(self.spawn_callback)
        self.change_pen_color(*self.bg_color, width=5, off=1)

        self.control_executed = False

    def spawn_callback(self, future):
        try:
            response = future.result()
            self.get_logger().info(f"Spawned turtle named: {response.name} at ({self.req.x}, {self.req.y})")

            # Wait for teleport_absolute first
            self.teleport_client = self.create_client(TeleportAbsolute, '/turtle5/teleport_absolute')
            while not self.teleport_client.wait_for_service(timeout_sec=1.0):
                self.get_logger().info('Waiting for /turtle5/teleport_absolute service...')

            self.teleport_to(self.req.x, self.req.y)

            # Now wait for /turtle3/set_pen service
           

        except Exception as e:
            self.get_logger().error(f"Service call failed: {e}")


    def teleport_to(self, x, y):
        #request = TeleportAbsolute.Request()
        #request.x = x
        #request.y = y
        #request.theta = 0.0
        #future = self.teleport_client.call_async(request)
        #rclpy.spin_until_future_complete(self, future)
        fsddfsfds=0
        self.teleport_to_new(x,y)


    def teleport_to_new(self, x, y, theta=0.0):
        turtle_name = self.req.name # You can change this dynamically if needed

        command = [
            "ros2", "service", "call",
            f"/{turtle_name}/teleport_absolute",
            "turtlesim/srv/TeleportAbsolute",
            f"{{x: {x}, y: {y}, theta: {theta}}}"
        ]

        try:
            self.get_logger().info(f"KKKKKKKKKLLLLLLLLLLLLLLL Executing command: {' '.join(command)}")
            result = subprocess.run(command, check=True, capture_output=True, text=True)
            self.get_logger().info("KKKKKKKKKLLLLLLLLLLLLLLL Teleport successful:\n" + result.stdout)
        except subprocess.CalledProcessError as e:
            self.get_logger().error("UUUUUUUUUUUUUUUU Failed to teleport turtle:\n" + e.stderr)


    def send_special_message(self):
        
        #self.pose_callback()
        message_data = {
            "position": {"x": self.current_pos[0], "y": self.current_pos[1]},
            "velocity": {"linear_x": self.velocity[0], "linear_y": self.velocity[1]},
            "line_number": self.line_number
        }
        msg = String()
        msg.data = json.dumps(message_data)
        self.special_message_publisher.publish(msg)

        time.sleep(1)
        #self.get_logger().info('Sent message is '+ str(msg))

    def pose_callback(self, msg):
        #self.get_logger().info(f"Turtle1 Position -> x: {msg.x:.2f}, y: {msg.y:.2f}, theta: {msg.theta:.2f}")
        a=2

  

    def change_pen_color(self, r, g, b, width=5, off=0):
        turtle_name = self.req.name

        # Properly escape the 'off' key using shell-safe escaping
        yaml_args = (
            f"'r: {r}\n"
            f"g: {g}\n"
            f"b: {b}\n"
            f"width: {width}\n"
            f"'\\''off'\\'': {off}'"
        )

        cmd = f"ros2 service call /{turtle_name}/set_pen turtlesim/srv/SetPen {yaml_args}"

        self.get_logger().info(f"Executing command:\n{cmd}")

        try:
            result = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
            self.get_logger().info("Pen change successful:\n" + result.stdout)
        except subprocess.CalledProcessError as e:
            self.get_logger().error("Failed to change pen color:\n" + e.stderr)
            self.get_logger().error("Entered command was:\n" + cmd)




    def special_message_callback(self, msg):
        try:
            if(not self.control_executed):
                data = json.loads(msg.data)
                self.ln = int(data.get("line_number", None))

                self.get_logger().info("Data Receieved is "+ str(msg.data))
                self.send_special_message()
                
                
            if self.ln is not None and self.ln > 2 and not self.control_executed:                
                self.get_logger().info("Triggering turtle sb3  control routine based on line_number > 9.")
                #self.req.x = self.start_x 
                #self.req.y = self.start_y 
                #self.teleport_to(self.start_x, self.start_y)
                
                self.control_executed = True
                self.control_turtle()
            

        except Exception as e:
            self.get_logger().error(f"Failed to process special message: {e}")

    def control_turtle(self):
        speed = 2.0
        length = 5.0
        breadth = 3.0
        line_duration = length / speed
        line_spacing = breadth / 10.0
        num_lines = 10
        #self.teleport_to(self.start_x,self.start_y )
        self.get_logger().info("SB3 SB3 SB3 LOL LOL ")
        self.teleport_to(self.start_x,self.start_y )
        self.get_logger().info("SB3 SB3asdadsdsa SB3 LOL LOL ")



        for i in range(num_lines):
            
            self.line_number=i
            message_data = {
            "position": {"x": self.current_pos[0], "y": self.current_pos[1]},
            "velocity": {"linear_x": self.velocity[0], "linear_y": self.velocity[1]},
            "line_number": self.line_number,
            "lol_man ": 0,
            }
            msg = String()
            msg.data = json.dumps(message_data)

            self.special_message_publisher.publish(msg)

            # Forward line
            self.change_pen_color(*self.color, width=2, off=0)

            twist = Twist()
            twist.linear.x = speed
            self.publisher_.publish(twist)
            time.sleep(line_duration)
            twist.linear.x = 0.0
            self.publisher_.publish(twist)

            # Move up
            self.change_pen_color(*self.bg_color, width=0, off=0)
            twist = Twist()
            twist.linear.y = line_spacing
            self.publisher_.publish(twist)
            time.sleep(1.0)
            twist.linear.y = 0.0
            self.publisher_.publish(twist)

            # Reverse line
            self.change_pen_color(*self.color, width=2, off=0)
            twist = Twist()
            twist.linear.x = -speed
            self.publisher_.publish(twist)
            time.sleep(line_duration)
            twist.linear.x = 0.0
            self.publisher_.publish(twist)

            # Move up again
            self.change_pen_color(*self.bg_color, width=0, off=0)
            twist = Twist()
            twist.linear.y = line_spacing
            self.publisher_.publish(twist)
            time.sleep(1.0)
            twist.linear.y = 0.0
            self.publisher_.publish(twist)
            self.get_logger().info("spawn_turtle5 Current Line is  " + str(i)+ " KKKKKKKKKKKKKpppppppppp")
            self.get_logger().info("spawn_turtle5  Published message is  "+ str(msg) +"KKKKKKKKKKKKKpppppppppp")
            self.special_message_publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = sb4()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
